function addTask(){
    const input = document.getElementById("taskInput");
    const taskTest = input.value.trim();

    if(taskTest == ""){
        alert("Digite uma tarefa!");
        return;
    }

    const list = document.getElementById("todoList");
    const li = document.createElement("li");
    li.className = "todo-item";
    li.innerHTML =` ${taskTest}
        <span class="taskText">${taskTest} </span>
        <button class="done-btn" onclick="doneTask(this)">Feito!</button>
        <button class="delete-btn" onclick="deleteTask(this)">Excluir</button>`;

    list.appendChild(li)
    input.value ="";
}

function deleteTask(button){
    const li = button.parentElement.parentElement;
    li.romove();
}

function doneTask(button){
    const texto = button.parentElement.previousElementSibling;
    texto.classList.toggle("done");
    button.classList.toggle("done-btn-a");
}
